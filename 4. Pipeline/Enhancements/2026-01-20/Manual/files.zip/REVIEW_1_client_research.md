# REVIEW 1: Client Research

**Reviewers:** Validator (automated) + Reviewer (manual)
**Inputs:** `CLIENT_PROFILE_{client_name}.md` from TASK_1

---

## Automated Checks (Validator)

Run these checks programmatically:

### Check 1.1: Required Fields Present
- [ ] EIN is 9 digits
- [ ] State is valid 2-letter code
- [ ] Budget is numeric and > 0
- [ ] At least 1 program area listed
- [ ] At least 1 population served listed
- [ ] Database fit score is calculated (0-100%)

**FAIL if:** Any required field missing or malformed

### Check 1.2: EIN Verification
```sql
SELECT COUNT(*) FROM f990_2025.nonprofit_returns 
WHERE ein = '{ein_from_profile}';
```
- [ ] Returns at least 1 row

**FAIL if:** EIN not found in database (may need manual lookup)

### Check 1.3: Budget Variance
- [ ] Compare questionnaire budget to IRS total_revenue
- [ ] Flag if variance > 50%

**WARN if:** Large variance (may indicate wrong EIN or outdated data)

### Check 1.4: Exclusion List Not Empty
- [ ] At least 1 funder in exclusion list (from questionnaire "existing funders")

**WARN if:** Empty exclusion list (client may not have answered questionnaire fully)

### Check 1.5: Database Fit Score Threshold
- [ ] Fit score ≥ 50%

**FAIL if:** < 50% (workflow may not be appropriate for this client)

---

## Manual Spot Checks (Reviewer)

Sample and verify 3 items:

### Spot Check A: EIN Matches Organization
- Web search the EIN on ProPublica or IRS
- Confirm organization name matches
- **FAIL if:** EIN belongs to different organization

### Spot Check B: Questionnaire Data Extracted Correctly
- Open original questionnaire CSV
- Verify 3 fields match profile (e.g., budget, location, program areas)
- **FAIL if:** Data copied incorrectly

### Spot Check C: Exclusion List Completeness
- Check if questionnaire "existing funders" field had entries
- Confirm all were added to exclusion list
- **FAIL if:** Known funders missing from exclusion list

---

## Pass Criteria

**ALL must be true to proceed:**

| Criterion | Status |
|-----------|--------|
| All required fields present | ☐ |
| EIN verified in database | ☐ |
| Database fit score ≥ 50% | ☐ |
| Spot Check A passed | ☐ |
| Spot Check B passed | ☐ |
| Spot Check C passed | ☐ |

---

## Common Issues & Fixes

| Issue | Fix |
|-------|-----|
| EIN not found | Search by name in database; verify on IRS website |
| Budget variance > 50% | Note in profile; may be fiscal year difference or growth |
| Fit score < 50% | Document in session notes; consider alternative approach or proceed with caution |
| Exclusion list empty | Re-check questionnaire; web search for known funders |
| Program areas vague | Clarify with more specific keywords for matching |

---

## Deliberation (If Issues Found)

If any check fails:

1. **Validator** documents specific failures
2. **Reviewer** assesses severity:
   - **Critical:** Must fix before proceeding (wrong EIN, missing data)
   - **Warning:** Note and proceed with caution (budget variance)
3. **Agree on fixes** - be specific:
   - "Re-query database with name search"
   - "Add {funder X} to exclusion list"
4. **Builder implements fixes**
5. **Re-run failed checks only**

---

## Sign-Off

```
REVIEW 1 COMPLETE

Client: ____________________
Date: ____________________

Automated Checks: ☐ PASS / ☐ FAIL
Manual Spot Checks: ☐ PASS / ☐ FAIL

Database Fit Score: ____%

Reviewer: ____________________
Validator: ____________________

☐ APPROVED TO PROCEED TO PHASE 2
☐ FIXES REQUIRED (see notes)
☐ ABORT WORKFLOW (fit score too low)

Notes:
_________________________________
_________________________________
```

---

*Review 1 v1.0*
