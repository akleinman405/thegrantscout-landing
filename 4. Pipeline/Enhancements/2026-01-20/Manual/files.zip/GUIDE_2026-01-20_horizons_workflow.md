# GUIDE: Horizons Foundation Matching Workflow

**Version:** 1.0
**Date:** 2026-01-20
**Based on:** Horizons National session (2026-01-20)
**Applies to:** Education/youth nonprofits, federated networks, organizations with 85%+ database fit

---

## Overview

This guide documents the workflow used to create the Horizons National foundation matching report. It's designed for nonprofits whose funding model is well-represented in 990-PF data (education, youth, arts sectors).

**Total Time:** ~4-6 hours
**Output:** 5-foundation report with positioning strategies and contacts

---

## Phase 1: Client Deep Research

**Goal:** Understand the client's funding model, why they signed up, and what they actually need.

**Time:** 30-45 minutes

### Inputs

| Input | Source | Purpose |
|-------|--------|---------|
| Questionnaire responses | `Grant Alerts Questionnaire.csv` | Self-reported needs, programs, populations |
| Client EIN | Questionnaire or lookup | Database key |
| Feedback call notes | `/6. Business/beta-testing/2. Feedback/` | Goals, preferences, what they liked/didn't |
| Customer type classification | `clients.md` | Calendar Manager vs Discovery Seeker etc. |

### Steps

1.1. **Extract questionnaire data**
- Organization name, EIN, location
- Budget, grant size seeking, capacity
- Program areas, populations served
- Geographic scope
- Existing funders (to exclude)
- Special requests or project needs

1.2. **Verify EIN and pull database info**
```sql
SELECT * FROM f990_2025.nonprofit_returns 
WHERE ein = '{client_ein}' 
ORDER BY tax_year DESC LIMIT 1;
```

1.3. **Compare questionnaire vs IRS data**
- Budget variance (flag if >50%)
- Mission alignment
- Employee count

1.4. **Research actual funding sources**
- Web search: "{org name} funders donors grants"
- Check Cause IQ for funder relationships
- Check ProPublica Nonprofit Explorer

1.5. **Read feedback notes**
- Why did they sign up?
- What do they actually want?
- What worked/didn't in prior reports?

1.6. **Calculate database fit score**
- What % of their funder types are in 990-PF?
- >70% = good fit, proceed
- <50% = consider alternative approach

### Outputs

| Output | Format | Location |
|--------|--------|----------|
| Client profile | Markdown section | `CLIENT_PROFILES_{date}.md` |
| Database fit score | Percentage | Documented in profile |
| Exclusion list | List of EINs | Working notes |

---

## Phase 2: Network Analysis

**Goal:** For federated orgs, map the affiliate network and identify prior funders to exclude.

**Time:** 20-30 minutes

**Skip if:** Client is a single-site nonprofit

### Inputs

| Input | Source | Purpose |
|-------|--------|---------|
| Client profile | Phase 1 output | Affiliate locations |
| Client website | Web | Affiliate list with locations |
| Database | f990_2025 | Affiliate EINs and grants |

### Steps

2.1. **Identify all affiliates**
- Web search for affiliate/chapter list
- Extract: Name, City, State, EIN (if findable)

2.2. **Find affiliate EINs in database**
```sql
SELECT ein, name, city, state 
FROM f990_2025.nonprofit_returns
WHERE LOWER(name) LIKE '%horizons%'
  AND LOWER(name) LIKE '%student%' OR LOWER(name) LIKE '%enrichment%';
```

2.3. **Pull all grants TO affiliates**
```sql
SELECT fg.* 
FROM f990_2025.fact_grants fg
WHERE fg.recipient_ein IN ('{affiliate_ein_1}', '{affiliate_ein_2}', ...);
```

2.4. **Identify prior funders to EXCLUDE**
- Foundations that have already funded any affiliate
- These go on exclusion list (or separate "stewardship" list)

### Outputs

| Output | Format | Location |
|--------|--------|----------|
| Network affiliates | CSV | `DATA_{date}_network_affiliates.csv` |
| Grants to network | CSV | `DATA_{date}_network_all_grants.csv` |
| Prior funders list | CSV | `DATA_{date}_prior_funders.csv` |

---

## Phase 3: Foundation Query

**Goal:** Generate an UNVETTED list of foundation candidates from the database.

**Time:** 30-45 minutes

### Inputs

| Input | Source | Purpose |
|-------|--------|---------|
| Client profile | Phase 1 | Keywords, geography, grant size |
| Prior funders list | Phase 2 | Exclusions |
| Affiliate cities | Phase 2 | Geographic filter |

### Steps

3.1. **Define search parameters**
- Keywords for grant purpose matching (e.g., "youth", "education", "summer", "enrichment")
- Geographic filter (affiliate states/cities)
- Asset minimum based on grant size sought
- IRS open indicator filter

3.2. **Query for foundations with target grants**
```sql
-- Find foundations that gave relevant grants in affiliate cities
WITH target_grants AS (
    SELECT fg.foundation_ein, fg.recipient_name_raw, fg.recipient_city,
           fg.recipient_state, fg.amount, fg.purpose_text, fg.tax_year
    FROM f990_2025.fact_grants fg
    WHERE fg.recipient_state IN ('PA', 'MA', 'CA', 'CO', ...)  -- affiliate states
      AND fg.amount BETWEEN 10000 AND 500000
      AND fg.tax_year >= 2020
      AND (
          LOWER(fg.purpose_text) LIKE '%youth%'
          OR LOWER(fg.purpose_text) LIKE '%education%'
          OR LOWER(fg.purpose_text) LIKE '%summer%'
          OR LOWER(fg.purpose_text) LIKE '%enrichment%'
      )
),
...
```

3.3. **Add hyperlocal filter**
- Count grants per foundation in specific affiliate CITIES
- Rank by `grants_in_affiliate_cities`
- This catches sub-regional foundations (Pittsburgh vs Philadelphia)

3.4. **Exclude prior funders**
```sql
WHERE fg.foundation_ein NOT IN (SELECT ein FROM prior_funders)
```

3.5. **Pull foundation details**
```sql
SELECT pf.ein, pf.business_name, pf.state, pf.total_assets_eoy_amt,
       pf.only_contri_to_preselected_ind, pf.website_url
FROM f990_2025.pf_returns pf
WHERE pf.ein IN (SELECT foundation_ein FROM target_grants)
ORDER BY pf.tax_year DESC;
```

3.6. **Generate candidate list with evidence**
- Foundation name, EIN, state, assets
- # of relevant grants, grant size range
- IRS open indicator
- 2-3 sample grants as evidence

### Outputs

| Output | Format | Location |
|--------|--------|----------|
| Hyperlocal prospects | CSV | `DATA_{date}_hyperlocal_prospects.csv` |
| Candidate count | Number | 40-50 candidates typical |

---

## Phase 4: Web Verification

**Goal:** Verify each candidate via web research. Classify as POSSIBLE / UNLIKELY / NOT ELIGIBLE.

**Time:** 2-3 hours (most time-intensive phase)

### Inputs

| Input | Source | Purpose |
|-------|--------|---------|
| Hyperlocal prospects CSV | Phase 3 | Candidates to verify |
| Client profile | Phase 1 | Eligibility criteria to check |

### Steps

4.1. **Prioritize candidates**
- Order by: grants_in_affiliate_cities DESC, assets DESC
- Start with highest-signal foundations

4.2. **For each foundation, research:**

**Question 1: Do they accept unsolicited applications?**
- Search: "{foundation name} grants application how to apply"
- Look for: "How to apply", "Grant guidelines", application portal
- Red flags: "By invitation only", "Does not accept unsolicited requests"
- Note: IRS indicator is unreliable - website is source of truth

**Question 2: What is their geographic focus?**
- Search: "{foundation name} geographic focus service area"
- Check for sub-regional restrictions (Pittsburgh only, not all PA)
- Does affiliate city qualify?

**Question 3: What are their funding priorities?**
- Look for: "What we fund", program areas
- Does client's work align?
- Note any restrictions (no general ops, no salaries, etc.)

**Question 4: Are there current RFPs or deadlines?**
- Search: "{foundation name} RFP 2026" or "grants deadline"
- Note any time-sensitive opportunities

**Question 5: Contact information**
- Find program officer names
- LinkedIn profiles
- Direct emails if available

4.3. **Classify each foundation**

| Status | Criteria |
|--------|----------|
| **POSSIBLE** | Accepts apps, geography matches, program aligns |
| **UNLIKELY** | Geographic mismatch OR wrong program focus |
| **NOT ELIGIBLE** | Invite-only OR completely wrong focus OR closed |

4.4. **Document sources**
- URL for every claim
- Date accessed

### Outputs

| Output | Format | Location |
|--------|--------|----------|
| Verified prospects | CSV with status column | `DATA_{date}_verified_prospects.csv` |
| Research notes | Markdown | Session report or working notes |
| POSSIBLE count | Number | Target: 12-20 for selecting top 5 |

---

## Phase 5: Report Assembly

**Goal:** Select top 5 foundations and build client-ready report.

**Time:** 1-2 hours

### Inputs

| Input | Source | Purpose |
|-------|--------|---------|
| Verified prospects | Phase 4 | POSSIBLE foundations |
| Research notes | Phase 4 | Details for each foundation |
| Client profile | Phase 1 | Positioning context |
| Affiliate mapping | Phase 2 | Which foundation for which affiliate |

### Steps

5.1. **Select top 5 foundations**

Selection criteria:
- Verified POSSIBLE status
- Strong evidence (multiple relevant grants)
- Geographic match to major affiliates
- Accessible application process
- Appropriate grant size
- Diversity (different regions/affiliates)

5.2. **Build Foundation Snapshot for each**

| Metric | Source |
|--------|--------|
| Assets | Database (pf_returns) |
| Annual giving | Database or web |
| Typical grant | Calculate median from grants |
| Grant range | Min-max from grants |
| Geographic focus | Web research |
| Giving trend | Compare years |

5.3. **Pull Proof-of-Fit Grants**
- 3-5 grants that demonstrate they fund similar work
- Include: Recipient, Amount, Purpose, Year
- Choose most relevant, not just largest

5.4. **Write Positioning Strategy**
- Lead message (1 sentence)
- 3-4 talking points
- Reference comparable grantees
- Note any concerns and how to address

5.5. **Add Contact Information**
- Primary contact: Name, title, LinkedIn, why them
- Secondary/executive contact for relationship elevation
- Application contact (email, phone)

5.6. **Document Application Process**
- Status: OPEN / DEADLINE / BY INVITATION
- Method: LOI, portal, letter, phone
- Deadlines if applicable
- Website URL

5.7. **Write Recommended Next Steps**
- 3-4 specific actions
- Time-sensitive items flagged
- Who should take each action (affiliate ED, national office, etc.)

5.8. **Add Time-Sensitive Callouts**
- Upcoming deadlines in executive summary
- Active RFPs highlighted
- Urgency markers where appropriate

5.9. **Write Methodology Appendix**
- How foundations were found
- Data sources used
- Limitations disclosed

5.10. **Create Next Steps Checklist**
- Immediate actions (this week)
- Short-term actions (this month)
- Ongoing relationship building

### Outputs

| Output | Format | Location |
|--------|--------|----------|
| Final report | Markdown | `OUTPUT_{date}_{client}_foundation_report.md` |
| PDF version | PDF | For client delivery |

---

## Phase 6: Quality Review

**Goal:** Verify accuracy before delivery.

**Time:** 30 minutes

### Inputs

| Input | Source | Purpose |
|-------|--------|---------|
| Final report | Phase 5 | Document to review |

### Steps

6.1. **Fact-check critical claims**
- Verify current RFPs exist (web search)
- Confirm deadlines are accurate
- Check that foundations still accept applications

6.2. **Check for funding restrictions**
- Note restrictions client needs to know (no general ops, etc.)
- Add warning boxes if critical

6.3. **Verify contact information**
- LinkedIn links work
- Names/titles are current

6.4. **Review positioning for accuracy**
- Comparable grantees actually received similar grants
- Talking points match foundation priorities

6.5. **Proofread**
- Typos, formatting consistency
- Links work

### Outputs

| Output | Format | Location |
|--------|--------|----------|
| Reviewed report | Markdown | Same file, updated |
| Issues found | List | Fix before delivery |

---

## Summary: Inputs & Outputs by Phase

| Phase | Key Inputs | Key Outputs |
|-------|------------|-------------|
| **1. Client Research** | Questionnaire, feedback notes, database | Client profile, exclusion list, fit score |
| **2. Network Analysis** | Client website, database | Affiliate list, prior funders CSV |
| **3. Foundation Query** | Keywords, geography, exclusions | Hyperlocal prospects CSV (40-50) |
| **4. Web Verification** | Prospects CSV | Verified prospects with status (12-20 POSSIBLE) |
| **5. Report Assembly** | Verified prospects, research notes | Final report (5 foundations) |
| **6. Quality Review** | Final report | Reviewed report ready for delivery |

---

## When to Use This Workflow

**Good fit:**
- Education / youth development nonprofits
- Arts & culture organizations
- Federated networks with local affiliates
- Organizations with clear geographic focus
- Database fit score > 70%

**Poor fit:**
- Government-funded organizations (senior services, housing)
- Organizations funded primarily through DAFs (Jewish community orgs)
- Global/international programs
- Organizations whose peers don't receive foundation grants

---

## Lessons Learned from Horizons

1. **Hyperlocal matters** - PA foundations often fund Pittsburgh OR Philadelphia, not both
2. **IRS indicator is unreliable** - ~30% of "open" foundations are actually invite-only
3. **Check for funding restrictions** - Yawkey won't fund general ops or salaries
4. **Verify RFPs are current** - RFPs expire; always check dates
5. **Prior funders are valuable intel** - Even if excluded from "new discovery," useful for stewardship
6. **35% hit rate is normal** - Expect to verify 40+ foundations to find 15 POSSIBLE

---

*Guide created 2026-01-20 based on Horizons National workflow*
