# ORCHESTRATOR: Foundation Matching Report

**Version:** 1.0
**Date:** 2026-01-20
**Workflow Type:** Education/Youth Nonprofit Foundation Matching

---

## Overview

This orchestrator coordinates the creation of a foundation matching report through 6 phases. Each phase has a TASK file (what to do) and a REVIEW file (quality gate before proceeding).

**No phase proceeds until its REVIEW passes.**

---

## Agent Assignments

| Role | Phases | Responsibility |
|------|--------|----------------|
| **Data Engineer** | 1, 2, 3 | Database queries, data extraction, CSV generation |
| **Scout** | 4 | Web research, verification, contact discovery |
| **Builder** | 5 | Report assembly, writing, formatting |
| **Validator** | 1-6 Reviews | Automated checks, consistency verification |
| **Reviewer** | All Reviews | Manual spot checks, deliberation on fixes |

---

## Workflow

```
┌─────────────────────────────────────────────────────────────────┐
│  PHASE 1: Client Research                                       │
│  Agent: Data Engineer                                           │
│  Task: TASK_1_client_research.md                                │
│  Review: REVIEW_1_client_research.md                            │
│  Pass Criteria: Client profile complete, fit score calculated   │
└─────────────────────────────────────────────────────────────────┘
                              ↓ PASS
┌─────────────────────────────────────────────────────────────────┐
│  PHASE 2: Network Analysis                                      │
│  Agent: Data Engineer                                           │
│  Task: TASK_2_network_analysis.md                               │
│  Review: REVIEW_2_network_analysis.md                           │
│  Pass Criteria: Affiliates mapped, prior funders identified     │
│  (Skip if single-site nonprofit)                                │
└─────────────────────────────────────────────────────────────────┘
                              ↓ PASS
┌─────────────────────────────────────────────────────────────────┐
│  PHASE 3: Foundation Query                                      │
│  Agent: Data Engineer                                           │
│  Task: TASK_3_foundation_query.md                               │
│  Review: REVIEW_3_foundation_query.md                           │
│  Pass Criteria: 30-60 candidates, geography filter applied      │
└─────────────────────────────────────────────────────────────────┘
                              ↓ PASS
┌─────────────────────────────────────────────────────────────────┐
│  PHASE 4: Web Verification                                      │
│  Agent: Scout                                                   │
│  Task: TASK_4_web_verification.md                               │
│  Review: REVIEW_4_web_verification.md                           │
│  Pass Criteria: 12+ POSSIBLE foundations, all claims sourced    │
└─────────────────────────────────────────────────────────────────┘
                              ↓ PASS
┌─────────────────────────────────────────────────────────────────┐
│  PHASE 5: Report Assembly                                       │
│  Agent: Builder                                                 │
│  Task: TASK_5_report_assembly.md                                │
│  Review: REVIEW_5_report_assembly.md                            │
│  Pass Criteria: 5 foundations profiled, all sections complete   │
└─────────────────────────────────────────────────────────────────┘
                              ↓ PASS
┌─────────────────────────────────────────────────────────────────┐
│  PHASE 6: Final Review                                          │
│  Agent: Validator + Reviewer                                    │
│  Task: TASK_6_final_review.md                                   │
│  Review: REVIEW_6_final_review.md                               │
│  Pass Criteria: All links work, deadlines verified, ready       │
└─────────────────────────────────────────────────────────────────┘
                              ↓ PASS
                        [DELIVER REPORT]
```

---

## Review Process (Same for All Phases)

When a TASK is complete:

1. **Validator runs automated checks** from REVIEW file
2. **Reviewer does manual spot checks** (samples 3 items)
3. **If issues found:**
   - Validator + Reviewer deliberate
   - Agree on specific fixes needed
   - Builder/Agent implements fixes
   - Re-run checks
4. **If all checks pass:** Proceed to next phase

---

## File Outputs by Phase

| Phase | Output Files |
|-------|--------------|
| 1 | `CLIENT_PROFILE_{client}.md` |
| 2 | `DATA_{date}_affiliates.csv`, `DATA_{date}_prior_funders.csv` |
| 3 | `DATA_{date}_foundation_candidates.csv` |
| 4 | `DATA_{date}_verified_foundations.csv` |
| 5 | `OUTPUT_{date}_{client}_foundation_report.md` |
| 6 | Final reviewed report (same file, updated) |

---

## Starting a New Report

1. Identify client from questionnaire
2. Confirm client type is "education/youth" (good fit for this workflow)
3. Create working directory: `/reports/{client_name}/`
4. Begin TASK_1

---

## Abort Conditions

Stop the workflow if:
- Phase 1: Database fit score < 50%
- Phase 3: < 15 candidates after query (need different approach)
- Phase 4: < 5 POSSIBLE after verification (client may not be good fit)

If abort, document in `REPORT_{date}_session.md` and discuss alternative approach.

---

*Orchestrator v1.0 - 2026-01-20*
