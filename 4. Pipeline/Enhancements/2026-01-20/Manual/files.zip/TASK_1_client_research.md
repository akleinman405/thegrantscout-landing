# TASK 1: Client Research

**Agent:** Data Engineer
**Time:** 30-45 minutes
**Prerequisite:** Client identified from questionnaire

---

## Goal

Build a complete client profile with funding model analysis and database fit score.

---

## Inputs Required

| Input | Location | Required |
|-------|----------|----------|
| Questionnaire responses | `Grant Alerts Questionnaire.csv` | ✓ |
| Client EIN | Questionnaire or web lookup | ✓ |
| Feedback call notes | `/6. Business/beta-testing/2. Feedback/` | If exists |
| Customer classification | `clients.md` | If exists |

---

## Steps

### 1.1 Extract Questionnaire Data

Pull from questionnaire CSV:
- [ ] Organization name
- [ ] EIN (or note if missing - will need lookup)
- [ ] Location (city, state)
- [ ] Annual budget
- [ ] Grant size seeking
- [ ] Grant management capacity
- [ ] Primary program areas (up to 5)
- [ ] Populations served
- [ ] Geographic scope
- [ ] Mission statement (1-2 sentences)
- [ ] Specific timeframes/projects
- [ ] Existing funders (CRITICAL - these are exclusions)
- [ ] Additional notes

### 1.2 Verify EIN in Database

```sql
SELECT ein, name, city, state, total_revenue, total_assets, 
       total_expenses, employee_cnt
FROM f990_2025.nonprofit_returns
WHERE ein = '{client_ein}'
ORDER BY tax_year DESC 
LIMIT 1;
```

If EIN not found or doesn't match:
```sql
SELECT ein, name, city, state
FROM f990_2025.nonprofit_returns
WHERE LOWER(name) LIKE '%{org_name_keywords}%'
  AND state = '{state}'
ORDER BY total_revenue DESC
LIMIT 10;
```

Record:
- [ ] Verified EIN
- [ ] IRS name (may differ from questionnaire)
- [ ] Revenue from IRS vs questionnaire budget (flag if >50% variance)

### 1.3 Check for Grants Received

```sql
SELECT fg.foundation_name, fg.amount, fg.purpose_text, fg.tax_year
FROM f990_2025.fact_grants fg
WHERE fg.recipient_ein = '{client_ein}'
ORDER BY fg.tax_year DESC, fg.amount DESC
LIMIT 20;
```

Record:
- [ ] Number of grants found in database
- [ ] Top 5 foundation funders (if any)
- [ ] Add these to exclusion list

### 1.4 Research Actual Funding Sources

Web search: "{org name} funders donors grants annual report"

Check:
- [ ] Cause IQ (if accessible)
- [ ] ProPublica Nonprofit Explorer
- [ ] Organization's annual report/website

Record:
- [ ] Major funders not in database
- [ ] Funder types: Foundation / Government / Corporate / Individual / DAF
- [ ] Estimate % from each type

### 1.5 Calculate Database Fit Score

| Funder Type | In 990-PF? | Weight |
|-------------|------------|--------|
| Private foundations | Yes | Count |
| Corporate foundations | Yes | Count |
| Community foundations | Partial | Count × 0.5 |
| Government grants | No | 0 |
| DAFs/Federated | No | 0 |
| Individual donors | No | 0 |

**Fit Score = (Funders in 990-PF) / (Total Known Funders) × 100**

- ≥70%: Good fit, proceed
- 50-69%: Marginal, proceed with caution
- <50%: Poor fit, consider different approach

### 1.6 Read Feedback Notes (if available)

If client has prior feedback calls, extract:
- [ ] Why did they sign up?
- [ ] What do they actually want?
- [ ] Customer type (Calendar Manager / Discovery Seeker / etc.)
- [ ] Preferences or complaints

### 1.7 Build Exclusion List

Compile all known funders to EXCLUDE from new discovery:
- Questionnaire "existing funders"
- Database grants received
- Web research funders

Format as list of foundation names (EINs if available).

---

## Output

Create file: `CLIENT_PROFILE_{client_name}.md`

```markdown
# Client Profile: {Organization Name}

## Basic Information
- **EIN:** {ein}
- **Location:** {city}, {state}
- **Budget:** ${amount} (IRS: ${irs_amount})
- **Employees:** {count}

## Mission
{1-2 sentence mission from questionnaire}

## Program Areas
1. {area 1}
2. {area 2}
...

## Populations Served
- {population 1}
- {population 2}
...

## Geographic Scope
{local / regional / statewide / national}

## Grant Seeking
- **Size seeking:** ${min} - ${max}
- **Capacity:** {low / medium / high}
- **Timeframe:** {if specified}

## Funding Model Analysis

### Known Funders
| Funder | Type | In 990-PF? |
|--------|------|------------|
| {funder 1} | Foundation | Yes |
| {funder 2} | Government | No |
...

### Database Fit Score: {X}%
{Interpretation: Good fit / Marginal / Poor fit}

## Exclusion List
Foundations to exclude from new discovery:
- {funder 1}
- {funder 2}
...

## Customer Context
- **Why signed up:** {reason}
- **Customer type:** {type}
- **Special requests:** {if any}

## Keywords for Matching
- {keyword 1}
- {keyword 2}
...

---
*Profile created: {date}*
```

---

## Pass to Review

When complete, hand off to REVIEW_1 with:
1. `CLIENT_PROFILE_{client_name}.md`
2. Exclusion list (can be in profile or separate)
3. Database fit score

---

*Task 1 v1.0*
